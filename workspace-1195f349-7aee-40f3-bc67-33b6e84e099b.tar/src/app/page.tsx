'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Mail, 
  Phone, 
  MapPin, 
  Globe,
  ExternalLink,
  FileText,
  Briefcase,
  GraduationCap,
  Award,
  ChevronRight,
  Menu,
  X,
  Download,
  Building,
  Users,
  Shield,
  Database,
  Code,
  Plane,
  CreditCard
} from 'lucide-react';

export default function Portfolio() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [scrolled, setScrolled] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });
  const [formStatus, setFormStatus] = useState<'idle' | 'loading' | 'success' | 'error'>('idle');
  const [formMessage, setFormMessage] = useState('');

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
      
      const sections = ['home', 'about', 'experience', 'education', 'skills', 'certifications', 'contact'];
      const current = sections.find(section => {
        const element = document.getElementById(section);
        if (element) {
          const rect = element.getBoundingClientRect();
          return rect.top <= 100 && rect.bottom >= 100;
        }
        return false;
      });
      
      if (current) setActiveSection(current);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    element?.scrollIntoView({ behavior: 'smooth' });
    setIsMenuOpen(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('loading');
    setFormMessage('');

    try {
      const response = await fetch('https://formspree.io/f/mdkwzgbp', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify(formData)
      });

      if (response.ok) {
        setFormStatus('success');
        setFormMessage('Thank you for your message! I will get back to you soon.');
        setFormData({ name: '', email: '', subject: '', message: '' });
      } else {
        throw new Error('Form submission failed');
      }
    } catch (error) {
      setFormStatus('error');
      setFormMessage('Sorry, there was an error sending your message. Please try again.');
    }

    // Reset status after 5 seconds
    setTimeout(() => {
      setFormStatus('idle');
      setFormMessage('');
    }, 5000);
  };

  const coreSkills = [
    'Document Control', 'Public Relations', 'UAE Government Portals', 
    'Customer Service', 'Compliance', 'Visa Processing', 'IATA Portals', 'Tas-heel'
  ];

  const technicalSkills = [
    'HTML/CSS/PHP/MySQL', 'GitHub', 'ARTIFICIAL INTELLIGENCE', 
    'WordPress', 'ICT Tools', 'Basic Python'
  ];

  const experience = [
    {
      title: 'PRO & Document Controller',
      company: 'Habat Al Rimal Typing, Sharjah',
      period: 'May 2025 – Present',
      description: 'Managed UAE government applications and documentation workflows.',
      achievements: [
        'Managed UAE government applications (ICP, MOHRE, DED, Tas-heel, Emirates ID)',
        'Handled documentation workflows, visa processing, and direct customer service',
        'Provided support in IATA-approved flight ticket booking systems'
      ],
      icon: <FileText className="h-5 w-5" />
    },
    {
      title: 'Administration Manager / PRO',
      company: 'Al Rashidya Gas Trading, Dubai',
      period: 'Jun 2023 – May 2025',
      description: 'Managed all government relations and documentation for company licensing.',
      achievements: [
        'Managed all government relations and documentation for company licensing and permits',
        'Liaised with various UAE government departments (MOHRE, DED, Immigration, Labor)',
        'Processed employee visas, permits, and documentation requirements',
        'Handled company compliance matters and ensured regulatory adherence'
      ],
      icon: <Building className="h-5 w-5" />
    },
    {
      title: 'Filing Clerk',
      company: 'Al Mutawakkil Typing Services, Abu Dhabi',
      period: 'Jul 2021 – Feb 2023',
      description: 'Organized and updated records and legal documents.',
      achievements: [
        'Organized and updated records and legal documents',
        'Supported data entry, typing, and customer documentation needs'
      ],
      icon: <Database className="h-5 w-5" />
    },
    {
      title: 'IT Executive',
      company: 'Metrix Corporation, Chittagong',
      period: 'Jan 2016 – Dec 2018',
      description: 'Developed software solutions and provided IT support.',
      achievements: [
        'Developed news portal Ctgnewstoday (currently inactive)',
        'Created database software for hospitals/clinics and Chittagong Port',
        'Designed result publishing software for Chittagong Medical College',
        'Provided IT support and troubleshooting across multiple departments'
      ],
      icon: <Code className="h-5 w-5" />
    }
  ];

  const education = [
    {
      degree: 'M.Sc. Geography & Environment',
      institution: 'National University of Bangladesh',
      cgpa: '2.97/4.00',
      period: '2018 - 2020'
    },
    {
      degree: 'B.Sc. Geography & Environment',
      institution: 'National University of Bangladesh',
      cgpa: '3.02/4.00 – 1st Class',
      period: '2014 - 2018'
    },
    {
      degree: '1-Year ICT Diploma',
      institution: 'Islami Bank Institute of Technology, Chittagong',
      cgpa: null,
      period: '2019 - 2020'
    }
  ];

  const certifications = [
    {
      title: 'Certificate of Completion: PHP Course',
      issuer: 'Sololearn',
      date: 'Feb 2016',
      credentialId: 'CT-S4NGPDRA'
    },
    {
      title: 'Certificate of Completion: HTML Course',
      issuer: 'Sololearn',
      date: 'Feb 2016',
      credentialId: 'CT-LWZGFQLU'
    }
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${scrolled ? 'bg-background/95 backdrop-blur-sm border-b' : ''}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <span className="text-2xl font-bold text-primary">AI</span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {['home', 'about', 'experience', 'education', 'skills', 'certifications', 'contact'].map((section) => (
                  <button
                    key={section}
                    onClick={() => scrollToSection(section)}
                    className={`px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                      activeSection === section 
                        ? 'text-primary bg-primary/10' 
                        : 'text-muted-foreground hover:text-primary hover:bg-primary/5'
                    }`}
                  >
                    {section.charAt(0).toUpperCase() + section.slice(1)}
                  </button>
                ))}
              </div>
            </div>

            {/* Mobile menu button */}
            <div className="md:hidden">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsMenuOpen(!isMenuOpen)}
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-background border-b">
              {['home', 'about', 'experience', 'education', 'skills', 'certifications', 'contact'].map((section) => (
                <button
                  key={section}
                  onClick={() => scrollToSection(section)}
                  className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors ${
                    activeSection === section 
                      ? 'text-primary bg-primary/10' 
                      : 'text-muted-foreground hover:text-primary hover:bg-primary/5'
                  }`}
                >
                  {section.charAt(0).toUpperCase() + section.slice(1)}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="min-h-screen flex items-center justify-center px-4 pt-16">
        <div className="max-w-7xl mx-auto text-center animate-fade-in">
          <div className="mb-8">
            <div className="w-32 h-32 mx-auto mb-6 rounded-full overflow-hidden border-4 border-primary/20 animate-bounce-in">
              <img 
                src="https://aimzworld007.github.io/photo.jpg" 
                alt="Ainul Islam" 
                className="w-full h-full object-cover"
              />
            </div>
            <h1 className="text-4xl md:text-6xl font-bold mb-4 text-gradient">
              Ainul Islam
            </h1>
            <p className="text-xl md:text-2xl text-muted-foreground mb-6 animate-slide-up" style={{animationDelay: '0.2s'}}>
              Document Controller | Public Relations Officer
            </p>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-8 animate-slide-up" style={{animationDelay: '0.4s'}}>
              Document Controller and administrative professional with 4 years of experience in the UAE, 
              specializing in ICP, MOHRE, and DED government applications. Skilled in document control, 
              compliance, visa processing, and customer service.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12 animate-bounce-in" style={{animationDelay: '0.6s'}}>
            <Button size="lg" onClick={() => scrollToSection('contact')} className="card-hover">
              Get In Touch
              <ChevronRight className="ml-2 h-4 w-4" />
            </Button>
            <Button variant="outline" size="lg" className="card-hover" onClick={() => window.open('https://aimzworld007.github.io/Ainul_islam.cv.pdf', '_blank')}>
              <Download className="mr-2 h-4 w-4" />
              Download CV
            </Button>
          </div>

          <div className="flex justify-center space-x-4 animate-slide-up" style={{animationDelay: '0.8s'}}>
            <Button variant="ghost" size="sm" className="card-hover" onClick={() => window.open('https://aimnote.wordpress.com', '_blank')}>
              <Globe className="h-5 w-5" />
            </Button>
            <Button variant="ghost" size="sm" className="card-hover" onClick={() => window.open('https://linkedin.com/in/aimzworld007', '_blank')}>
              <Users className="h-5 w-5" />
            </Button>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-6 mt-8 animate-slide-up" style={{animationDelay: '1s'}}>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4" />
              <span>Sharjah, U.A.E</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Mail className="h-4 w-4" />
              <span>Aimctgbd@gmail.com</span>
            </div>
            <div className="flex items-center space-x-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>+971 52 284 9291</span>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">About Me</h2>
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-semibold mb-4 text-primary">Career Objective</h3>
              <p className="text-lg text-muted-foreground mb-6">
                Document Controller and administrative professional with 4 years of experience in the UAE, 
                specializing in ICP, MOHRE, and DED government applications. Skilled in document control, 
                compliance, visa processing, and customer service.
              </p>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>Sharjah, U.A.E</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>Aimctgbd@gmail.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-primary" />
                  <span>+971 52 284 9291</span>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Card className="card-hover">
                <CardContent className="p-6 text-center">
                  <Briefcase className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">4 Years</h3>
                  <p className="text-sm text-muted-foreground">Experience</p>
                </CardContent>
              </Card>
              <Card className="card-hover">
                <CardContent className="p-6 text-center">
                  <Shield className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">UAE Gov</h3>
                  <p className="text-sm text-muted-foreground">Specialist</p>
                </CardContent>
              </Card>
              <Card className="card-hover">
                <CardContent className="p-6 text-center">
                  <FileText className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Document</h3>
                  <p className="text-sm text-muted-foreground">Control</p>
                </CardContent>
              </Card>
              <Card className="card-hover">
                <CardContent className="p-6 text-center">
                  <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                  <h3 className="font-semibold">Public</h3>
                  <p className="text-sm text-muted-foreground">Relations</p>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Experience Section */}
      <section id="experience" className="py-20 px-4 bg-muted/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Professional Experience</h2>
          <div className="space-y-8">
            {experience.map((job, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        {job.icon}
                      </div>
                      <div>
                        <CardTitle className="text-xl">{job.title}</CardTitle>
                        <CardDescription className="text-lg font-medium text-primary">
                          {job.company}
                        </CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline" className="mt-2 md:mt-0">
                      {job.period}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{job.description}</p>
                  <ul className="space-y-2">
                    {job.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="flex items-start">
                        <ChevronRight className="h-4 w-4 mr-2 mt-0.5 text-primary flex-shrink-0" />
                        <span className="text-sm">{achievement}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Education Section */}
      <section id="education" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Education</h2>
          <div className="space-y-6">
            {education.map((edu, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:justify-between md:items-start">
                    <div className="flex items-start space-x-3">
                      <div className="p-2 bg-primary/10 rounded-lg">
                        <GraduationCap className="h-5 w-5" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{edu.degree}</CardTitle>
                        <CardDescription className="font-medium">
                          {edu.institution}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="mt-2 md:mt-0 text-right">
                      <Badge variant="outline">{edu.period}</Badge>
                      {edu.cgpa && <p className="text-sm text-muted-foreground mt-1">CGPA: {edu.cgpa}</p>}
                    </div>
                  </div>
                </CardHeader>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20 px-4 bg-muted/50">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Skills & Expertise</h2>
          <Tabs defaultValue="core" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="core">Core Skills</TabsTrigger>
              <TabsTrigger value="technical">Technical Skills</TabsTrigger>
            </TabsList>
            <TabsContent key="core" value="core" className="mt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {coreSkills.map((skill) => (
                  <Card key={skill} className="text-center card-hover">
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="text-sm">{skill}</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            <TabsContent key="technical" value="technical" className="mt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {technicalSkills.map((skill) => (
                  <Card key={skill} className="text-center card-hover">
                    <CardContent className="p-4">
                      <Badge variant="secondary" className="text-sm">{skill}</Badge>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Certifications Section */}
      <section id="certifications" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Certifications</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <Card key={index} className="card-hover">
                <CardHeader>
                  <div className="flex items-start space-x-3">
                    <div className="p-2 bg-primary/10 rounded-lg">
                      <Award className="h-5 w-5" />
                    </div>
                    <div>
                      <CardTitle className="text-lg">{cert.title}</CardTitle>
                      <CardDescription>{cert.issuer}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <Badge variant="outline">{cert.date}</Badge>
                    <p className="text-sm text-muted-foreground">ID: {cert.credentialId}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-12">Get In Touch</h2>
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Contact Information</h3>
              <p className="text-muted-foreground mb-8">
                Feel free to reach out for professional inquiries, collaboration opportunities, 
                or if you need assistance with document control and PRO services in the UAE.
              </p>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Mail className="h-5 w-5 text-primary" />
                  <span>Aimctgbd@gmail.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-primary" />
                  <span>+971 52 284 9291</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-primary" />
                  <span>Sharjah, U.A.E</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Globe className="h-5 w-5 text-primary" />
                  <span>aimnote.wordpress.com</span>
                </div>
              </div>
              <div className="flex space-x-4 mt-8">
                <Button variant="outline" size="sm" className="card-hover" onClick={() => window.open('https://aimnote.wordpress.com', '_blank')}>
                  <Globe className="h-4 w-4 mr-2" />
                  Website
                </Button>
                <Button variant="outline" size="sm" className="card-hover" onClick={() => window.open('https://linkedin.com/in/aimzworld007', '_blank')}>
                  <Users className="h-4 w-4 mr-2" />
                  LinkedIn
                </Button>
              </div>
            </div>
            <Card>
              <CardHeader>
                <CardTitle>Send Me a Message</CardTitle>
                <CardDescription>
                  Fill out the form below and I'll get back to you as soon as possible.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <form onSubmit={handleSubmit}>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-sm font-medium">Name</label>
                      <input 
                        type="text" 
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        className="w-full mt-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Your Name"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Email</label>
                      <input 
                        type="email" 
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        className="w-full mt-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                        placeholder="Your Email"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium">Subject</label>
                    <input 
                      type="text" 
                      name="subject"
                      value={formData.subject}
                      onChange={handleInputChange}
                      required
                      className="w-full mt-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary"
                      placeholder="Subject"
                    />
                  </div>
                  <div>
                    <label className="text-sm font-medium">Message</label>
                    <textarea 
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      required
                      className="w-full mt-1 px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-primary h-32 resize-none"
                      placeholder="Your Message"
                    />
                  </div>
                  
                  {formMessage && (
                    <div className={`p-3 rounded-md text-sm ${
                      formStatus === 'success' 
                        ? 'bg-green-100 text-green-800 border border-green-200' 
                        : 'bg-red-100 text-red-800 border border-red-200'
                    }`}>
                      {formMessage}
                    </div>
                  )}
                  
                  <Button 
                    type="submit" 
                    className="w-full"
                    disabled={formStatus === 'loading'}
                  >
                    {formStatus === 'loading' ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Sending...
                      </>
                    ) : (
                      <>
                        Send Message
                        <Mail className="ml-2 h-4 w-4" />
                      </>
                    )}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-muted/50 py-8 px-4">
        <div className="max-w-7xl mx-auto text-center">
          <p className="text-muted-foreground">
            © 2024 Ainul Islam. All rights reserved. Professional Portfolio - Document Controller & PRO
          </p>
        </div>
      </footer>
    </div>
  );
}
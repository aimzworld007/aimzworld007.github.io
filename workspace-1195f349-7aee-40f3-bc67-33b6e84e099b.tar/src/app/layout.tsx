import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Ainul Islam - Document Controller & PRO | Professional Portfolio",
  description: "Professional portfolio of Ainul Islam, a Document Controller & Public Relations Officer with 3+ years of experience in UAE government applications, visa processing, and compliance management.",
  keywords: ["Ainul Islam", "Document Controller", "PRO", "Public Relations Officer", "UAE Government", "ICP", "MOHRE", "DED", "Visa Processing", "Compliance", "Sharjah", "Dubai"],
  authors: [{ name: "Ainul Islam" }],
  openGraph: {
    title: "Ainul Islam - Document Controller & PRO Portfolio",
    description: "Professional portfolio showcasing expertise in document control, government relations, and administrative management",
    url: "https://ainulislam.dev",
    siteName: "Ainul Islam Portfolio",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ainul Islam - Document Controller & PRO",
    description: "Document Controller & Public Relations Officer with 3+ years of experience in UAE",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
